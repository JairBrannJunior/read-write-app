package Model;

/**
 *
 * @author Jair Brannn Junior RA: 2052075
 */
public class Provider implements java.io.Serializable{
    public int id;
    public String nome;
    public String cnpj;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getCnpj() {
        return cnpj;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}

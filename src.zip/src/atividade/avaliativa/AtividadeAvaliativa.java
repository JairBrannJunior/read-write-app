package atividade.avaliativa;

import View.TypeOptionView;

/**
 *
 * @author Jair Brannn Junior RA: 2052075
 */
public class AtividadeAvaliativa {
    public static void main(String[] args) {
        new TypeOptionView().setVisible(true);
    }
}

package Controller.Text;

import Controller.ControllerTextFile;

/**
 *
 * @author Jair Brannn Junior RA: 2052075
 */
public class ProviderController extends ControllerTextFile{
        public ProviderController(int typeFile) {
            setFile("Providers", typeFile);
        }
}

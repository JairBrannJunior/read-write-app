package Controller.Text;

import Controller.ControllerTextFile;

/**
 *
 * @author Jair Brannn Junior RA: 2052075
 */
public class ProductController extends ControllerTextFile{
        public ProductController(int typeFile) {
        setFile("Products", typeFile);
    }
}
